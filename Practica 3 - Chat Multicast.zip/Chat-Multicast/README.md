# chatMulticast
Chat sencillo implementado con SocketIO
Pruebalo aquí: https://chat-multicast.herokuapp.com/
